-- Create enum types for structured fields
CREATE TYPE public.marital_status AS ENUM ('single', 'divorced', 'widowed');
CREATE TYPE public.sector AS ENUM ('litai', 'sfaradi', 'hasidi', 'temani', 'other');
CREATE TYPE public.male_study_place AS ENUM ('yeshiva', 'kolel', 'work', 'combined', 'other');
CREATE TYPE public.female_study_place AS ENUM ('seminary', 'college', 'university', 'other');
CREATE TYPE public.openness_level AS ENUM ('very_open', 'open', 'moderate', 'conservative', 'very_conservative');
CREATE TYPE public.family_type AS ENUM ('ashkenazi', 'sfaradi', 'mixed');
CREATE TYPE public.gender AS ENUM ('male', 'female');

-- Create the registrants table
CREATE TABLE public.registrants (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  
  -- Gender
  gender public.gender NOT NULL,
  
  -- Personal details
  full_name TEXT NOT NULL,
  id_number TEXT NOT NULL,
  age INTEGER NOT NULL CHECK (age >= 18 AND age <= 99),
  height INTEGER NOT NULL CHECK (height >= 140 AND height <= 220),
  marital_status public.marital_status NOT NULL,
  sector public.sector NOT NULL,
  origin TEXT NOT NULL,
  study_place TEXT NOT NULL,
  profession TEXT,
  openness_level public.openness_level NOT NULL,
  family_type public.family_type NOT NULL,
  city TEXT NOT NULL,
  about_me TEXT,
  looking_for TEXT,
  
  -- Partner preferences
  partner_age_min INTEGER NOT NULL DEFAULT 18 CHECK (partner_age_min >= 18),
  partner_age_max INTEGER NOT NULL DEFAULT 30 CHECK (partner_age_max <= 99),
  partner_height_min INTEGER NOT NULL DEFAULT 150 CHECK (partner_height_min >= 140),
  partner_height_max INTEGER NOT NULL DEFAULT 200 CHECK (partner_height_max <= 220),
  partner_study_place TEXT,
  partner_profession TEXT,
  partner_openness_level TEXT DEFAULT 'any',
  partner_family_type TEXT DEFAULT 'any',
  partner_city TEXT,
  
  -- Big Five personality results
  big_five_openness INTEGER CHECK (big_five_openness >= 0 AND big_five_openness <= 100),
  big_five_conscientiousness INTEGER CHECK (big_five_conscientiousness >= 0 AND big_five_conscientiousness <= 100),
  big_five_extraversion INTEGER CHECK (big_five_extraversion >= 0 AND big_five_extraversion <= 100),
  big_five_agreeableness INTEGER CHECK (big_five_agreeableness >= 0 AND big_five_agreeableness <= 100),
  big_five_neuroticism INTEGER CHECK (big_five_neuroticism >= 0 AND big_five_neuroticism <= 100),
  
  -- References (בירורים)
  reference1_name TEXT,
  reference1_phone TEXT,
  reference2_name TEXT,
  reference2_phone TEXT,
  reference3_name TEXT,
  reference3_phone TEXT
);

-- Enable RLS
ALTER TABLE public.registrants ENABLE ROW LEVEL SECURITY;

-- Allow anyone to insert (registration is public)
CREATE POLICY "Anyone can register" ON public.registrants
FOR INSERT WITH CHECK (true);

-- Allow reading own registration (by id_number for now since no auth)
CREATE POLICY "Anyone can view registrants" ON public.registrants
FOR SELECT USING (true);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_registrants_updated_at
BEFORE UPDATE ON public.registrants
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();