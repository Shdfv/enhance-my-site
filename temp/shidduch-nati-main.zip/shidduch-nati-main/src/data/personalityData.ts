import { BigFiveQuestion, BigFiveResult, UserProfile, MatchSuggestion } from '@/types/personality';

// Big Five questions in Hebrew - shuffled order
const allQuestions: BigFiveQuestion[] = [
  { id: 'o1', question: 'יש לי דמיון עשיר ופעיל', dimension: 'openness', reversed: false },
  { id: 'c1', question: 'אני מקפיד על סדר וארגון', dimension: 'conscientiousness', reversed: false },
  { id: 'e1', question: 'אני נהנה להיות במרכז תשומת הלב', dimension: 'extraversion', reversed: false },
  { id: 'a1', question: 'אני מתעניין באנשים אחרים ובבעיותיהם', dimension: 'agreeableness', reversed: false },
  { id: 'n1', question: 'אני נוטה לדאוג יותר מדי', dimension: 'neuroticism', reversed: false },
  
  { id: 'o2', question: 'אני נהנה לחשוב על רעיונות מופשטים', dimension: 'openness', reversed: false },
  { id: 'c2', question: 'אני עושה תוכניות ומקפיד לעקוב אחריהן', dimension: 'conscientiousness', reversed: false },
  { id: 'e2', question: 'אני אוהב לדבר הרבה', dimension: 'extraversion', reversed: false },
  { id: 'a2', question: 'אני מרגיש את רגשותיהם של אחרים', dimension: 'agreeableness', reversed: false },
  { id: 'n2', question: 'מצב הרוח שלי משתנה לעתים קרובות', dimension: 'neuroticism', reversed: false },
  
  { id: 'o3', question: 'אני מעדיף שגרה קבועה על פני גיוון', dimension: 'openness', reversed: true },
  { id: 'c3', question: 'לפעמים אני שוכח לעשות דברים שהבטחתי', dimension: 'conscientiousness', reversed: true },
  { id: 'e3', question: 'אני מרגיש נוח בקבוצות גדולות של אנשים', dimension: 'extraversion', reversed: false },
  { id: 'a3', question: 'לפעמים אני לא אכפתי מספיק לאחרים', dimension: 'agreeableness', reversed: true },
  { id: 'n3', question: 'אני נשאר רגוע גם במצבי לחץ', dimension: 'neuroticism', reversed: true },
  
  { id: 'o4', question: 'אני סקרן לגבי דברים רבים ושונים', dimension: 'openness', reversed: false },
  { id: 'c4', question: 'אני מסיים משימות ביסודיות', dimension: 'conscientiousness', reversed: false },
  { id: 'e4', question: 'אני שקט יחסית בפגישות חברתיות', dimension: 'extraversion', reversed: true },
  { id: 'a4', question: 'אני מוכן לעזור לאחרים בכל עת', dimension: 'agreeableness', reversed: false },
  { id: 'n4', question: 'אני מרגיש מתוח לעתים קרובות', dimension: 'neuroticism', reversed: false },
  
  { id: 'o5', question: 'אני פתוח לרעיונות חדשים ושונים', dimension: 'openness', reversed: false },
  { id: 'c5', question: 'אני מקפיד על פרטים קטנים', dimension: 'conscientiousness', reversed: false },
  { id: 'e5', question: 'אני יוזם שיחות עם אנשים חדשים', dimension: 'extraversion', reversed: false },
  { id: 'a5', question: 'אני משתדל לגרום לאחרים להרגיש בנוח', dimension: 'agreeableness', reversed: false },
  { id: 'n5', question: 'אני מתרגז בקלות', dimension: 'neuroticism', reversed: false },
];

export const bigFiveQuestions: BigFiveQuestion[] = allQuestions;

export const sampleProfiles: UserProfile[] = [
  {
    id: '1',
    name: 'יוסף כ.',
    age: 24,
    gender: 'male',
    location: 'בני ברק',
    height: 175,
    studyPlace: 'ישיבת פוניבז\'',
    profession: 'אברך',
    opennessLevel: 'moderate',
    familyType: 'ashkenazi',
    bio: 'לומד בכולל, אוהב גמרא וחסד. מחפש בת זוג לבניית בית של תורה.',
    matchPreference: 'balanced',
    bigFiveResult: {
      dimensions: {
        openness: 55,
        conscientiousness: 78,
        extraversion: 42,
        agreeableness: 72,
        neuroticism: 35,
      },
    },
  },
  {
    id: '2',
    name: 'מרים ל.',
    age: 22,
    gender: 'female',
    location: 'ירושלים',
    height: 162,
    studyPlace: 'סמינר בית יעקב',
    profession: 'גננת',
    opennessLevel: 'open',
    familyType: 'mixed',
    bio: 'בוגרת סמינר, עובדת בחינוך. מעריכה חום, משפחה וצמיחה רוחנית.',
    matchPreference: 'similar',
    bigFiveResult: {
      dimensions: {
        openness: 68,
        conscientiousness: 82,
        extraversion: 65,
        agreeableness: 88,
        neuroticism: 42,
      },
    },
  },
  {
    id: '3',
    name: 'דוד ש.',
    age: 26,
    gender: 'male',
    location: 'מודיעין עילית',
    height: 180,
    studyPlace: 'ישיבת מיר',
    profession: 'מתכנת',
    opennessLevel: 'open',
    familyType: 'sfaradi',
    bio: 'עובד כמתכנת עם סדר בוקר. מחפש מישהי עם ערכים דומים ומטרות משותפות.',
    matchPreference: 'complementary',
    bigFiveResult: {
      dimensions: {
        openness: 72,
        conscientiousness: 85,
        extraversion: 55,
        agreeableness: 68,
        neuroticism: 28,
      },
    },
  },
  {
    id: '4',
    name: 'חנה ר.',
    age: 23,
    gender: 'female',
    location: 'אלעד',
    height: 165,
    studyPlace: 'מכללת אורות',
    profession: 'מורה',
    opennessLevel: 'moderate',
    familyType: 'ashkenazi',
    bio: 'נפש יצירתית עם אהבה לאמנות ומוזיקה. מחפשת מישהו שמעריך גם מסורת וגם יצירתיות.',
    matchPreference: 'balanced',
    bigFiveResult: {
      dimensions: {
        openness: 85,
        conscientiousness: 65,
        extraversion: 48,
        agreeableness: 78,
        neuroticism: 52,
      },
    },
  },
  {
    id: '5',
    name: 'רבקה ג.',
    age: 21,
    gender: 'female',
    location: 'בית שמש',
    height: 158,
    studyPlace: 'סמינר וולף',
    profession: 'סייעת',
    opennessLevel: 'conservative',
    familyType: 'sfaradi',
    bio: 'לומדת להיות מורה. אוהבת ילדים ועבודה קהילתית. מחפשת בן תורה.',
    matchPreference: 'similar',
    bigFiveResult: {
      dimensions: {
        openness: 45,
        conscientiousness: 75,
        extraversion: 62,
        agreeableness: 82,
        neuroticism: 38,
      },
    },
  },
  {
    id: '6',
    name: 'שמואל מ.',
    age: 25,
    gender: 'male',
    location: 'ירושלים',
    height: 172,
    studyPlace: 'ישיבת חברון',
    profession: 'אברך ומדריך',
    opennessLevel: 'open',
    familyType: 'mixed',
    bio: 'לומד ומלמד בישיבה. אוהב חסידות ולעזור לאחרים לגדול.',
    matchPreference: 'balanced',
    bigFiveResult: {
      dimensions: {
        openness: 70,
        conscientiousness: 80,
        extraversion: 72,
        agreeableness: 85,
        neuroticism: 32,
      },
    },
  },
];

export function calculateBigFiveCompatibility(
  userResult: BigFiveResult,
  matchResult: BigFiveResult,
  preference: 'similar' | 'complementary' | 'balanced'
): { score: number; matchingDimensions: string[]; complementaryDimensions: string[] } {
  const dimensionNames: Record<string, string> = {
    openness: 'פתיחות',
    conscientiousness: 'מצפוניות',
    extraversion: 'מוחצנות',
    agreeableness: 'נעימות',
    neuroticism: 'יציבות רגשית',
  };

  let totalScore = 0;
  const matchingDimensions: string[] = [];
  const complementaryDimensions: string[] = [];

  const dimensions: Array<keyof BigFiveResult['dimensions']> = [
    'openness', 'conscientiousness', 'extraversion', 'agreeableness', 'neuroticism'
  ];

  dimensions.forEach((dim) => {
    const userScore = userResult.dimensions[dim];
    const matchScore = matchResult.dimensions[dim];
    const diff = Math.abs(userScore - matchScore);
    const isSimilar = diff <= 20; // Consider similar if within 20 points

    if (preference === 'similar') {
      if (isSimilar) {
        totalScore += 20;
        matchingDimensions.push(dimensionNames[dim]);
      } else {
        totalScore += Math.max(0, 10 - diff / 10);
      }
    } else if (preference === 'complementary') {
      if (!isSimilar) {
        totalScore += 20;
        complementaryDimensions.push(dimensionNames[dim]);
      } else {
        totalScore += 10;
      }
    } else {
      // balanced - mix is ideal
      if (isSimilar) {
        matchingDimensions.push(dimensionNames[dim]);
        totalScore += 16;
      } else {
        complementaryDimensions.push(dimensionNames[dim]);
        totalScore += 16;
      }
    }
  });

  // Bonus for balanced having a good mix
  if (preference === 'balanced') {
    if (matchingDimensions.length >= 2 && complementaryDimensions.length >= 1) {
      totalScore += 20;
    }
  }

  return {
    score: Math.min(100, Math.round(totalScore)),
    matchingDimensions: matchingDimensions.slice(0, 3),
    complementaryDimensions: complementaryDimensions.slice(0, 3),
  };
}

export function calculateBigFiveResult(answers: Record<string, number>): BigFiveResult {
  const dimensionScores: Record<string, number[]> = {
    openness: [],
    conscientiousness: [],
    extraversion: [],
    agreeableness: [],
    neuroticism: [],
  };

  // Group answers by dimension
  bigFiveQuestions.forEach((question) => {
    const answer = answers[question.id];
    if (answer !== undefined) {
      // For reversed questions, flip the score (1->5, 2->4, 3->3, 4->2, 5->1)
      const score = question.reversed ? (6 - answer) : answer;
      dimensionScores[question.dimension].push(score);
    }
  });

  // Calculate average for each dimension and convert to 0-100 scale
  const calculateAverage = (scores: number[]) => {
    if (scores.length === 0) return 50;
    const avg = scores.reduce((a, b) => a + b, 0) / scores.length;
    // Convert from 1-5 scale to 0-100 scale
    return Math.round(((avg - 1) / 4) * 100);
  };

  return {
    dimensions: {
      openness: calculateAverage(dimensionScores.openness),
      conscientiousness: calculateAverage(dimensionScores.conscientiousness),
      extraversion: calculateAverage(dimensionScores.extraversion),
      agreeableness: calculateAverage(dimensionScores.agreeableness),
      neuroticism: calculateAverage(dimensionScores.neuroticism),
    },
  };
}
