export type Gender = 'male' | 'female';

// Big Five personality dimensions
export type BigFiveDimension = 'openness' | 'conscientiousness' | 'extraversion' | 'agreeableness' | 'neuroticism';

export interface BigFiveQuestion {
  id: string;
  question: string;
  dimension: BigFiveDimension;
  reversed: boolean; // Some questions are reversed scored
}

export interface BigFiveResult {
  dimensions: {
    openness: number; // 1-100
    conscientiousness: number;
    extraversion: number;
    agreeableness: number;
    neuroticism: number;
  };
}

export type MaritalStatus = 'single' | 'divorced' | 'widowed';
export type Sector = 'litai' | 'sfaradi' | 'hasidi' | 'temani' | 'other';
export type MaleStudyPlace = 'yeshiva' | 'kolel' | 'work' | 'combined' | 'other';
export type FemaleStudyPlace = 'seminary' | 'college' | 'university' | 'other';

// Profile information for the user themselves
export interface SelfProfile {
  fullName: string;
  idNumber: string;
  age: number;
  height: number; // in cm
  maritalStatus: MaritalStatus;
  sector: Sector;
  origin: string;
  studyPlace: string;
  profession: string;
  opennessLevel: 'very_open' | 'open' | 'moderate' | 'conservative' | 'very_conservative';
  familyType: 'ashkenazi' | 'sfaradi' | 'mixed';
  city: string;
  aboutMe: string;
  lookingFor: string;
}

// References for background checks
export interface Reference {
  name: string;
  phone: string;
}

// Preferences for the partner they're looking for
export interface PartnerPreferences {
  ageMin: number;
  ageMax: number;
  heightMin: number;
  heightMax: number;
  studyPlace: string; // Can be empty for "doesn't matter"
  profession: string; // Can be empty for "doesn't matter"
  opennessLevel: 'very_open' | 'open' | 'moderate' | 'conservative' | 'very_conservative' | 'any';
  familyType: 'ashkenazi' | 'sfaradi' | 'mixed' | 'any';
  city: string; // Can be empty for "doesn't matter"
}

export interface UserProfile {
  id: string;
  name: string;
  age: number;
  gender: Gender;
  location: string;
  height: number; // in cm
  studyPlace: string;
  profession: string;
  opennessLevel: 'very_open' | 'open' | 'moderate' | 'conservative' | 'very_conservative';
  familyType: 'ashkenazi' | 'sfaradi' | 'mixed';
  bigFiveResult: BigFiveResult;
  bio: string;
  avatar?: string;
  matchPreference: 'similar' | 'complementary' | 'balanced';
}

export interface MatchSuggestion {
  user: UserProfile;
  compatibilityScore: number;
  matchingDimensions: string[];
  complementaryDimensions: string[];
}

// Marital status labels in Hebrew
export const maritalStatusLabels: Record<MaritalStatus, string> = {
  single: 'רווק/ה',
  divorced: 'גרוש/ה',
  widowed: 'אלמן/ה',
};

// Sector labels in Hebrew
export const sectorLabels: Record<Sector, string> = {
  litai: 'ליטאי',
  sfaradi: 'ספרדי',
  hasidi: 'חסידי',
  temani: 'תימני',
  other: 'אחר',
};

// Male study place labels in Hebrew
export const maleStudyPlaceLabels: Record<MaleStudyPlace, string> = {
  yeshiva: 'ישיבה',
  kolel: 'כולל',
  work: 'עבודה',
  combined: 'משלב',
  other: 'אחר',
};

// Female study place labels in Hebrew
export const femaleStudyPlaceLabels: Record<FemaleStudyPlace, string> = {
  seminary: 'סמינר',
  college: 'מכללה',
  university: 'אוניברסיטה',
  other: 'אחר',
};

// Openness level labels in Hebrew
export const opennessLabels: Record<string, string> = {
  very_open: 'מאוד פתוח',
  open: 'פתוח',
  moderate: 'בינוני',
  conservative: 'שמרני',
  very_conservative: 'מאוד שמרני',
  any: 'לא משנה',
};

// Family type labels in Hebrew
export const familyTypeLabels: Record<string, string> = {
  ashkenazi: 'אשכנזי',
  sfaradi: 'ספרדי',
  mixed: 'מעורב',
  any: 'לא משנה',
};

// Big Five dimension labels in Hebrew (without trait names shown to users)
export const bigFiveLabels: Record<BigFiveDimension, { name: string; description: string; high: string; low: string }> = {
  openness: { 
    name: 'פתיחות לחוויות', 
    description: 'סקרנות, יצירתיות והעדפה לגיוון',
    high: 'יצירתי וסקרן',
    low: 'מעשי ומסורתי'
  },
  conscientiousness: { 
    name: 'מצפוניות', 
    description: 'ארגון, אחריות ותכנון',
    high: 'מאורגן ואחראי',
    low: 'גמיש וספונטני'
  },
  extraversion: { 
    name: 'מוחצנות', 
    description: 'חברתיות, אנרגיה ותקשורתיות',
    high: 'חברתי ופעיל',
    low: 'שקט ומופנם'
  },
  agreeableness: { 
    name: 'נעימות', 
    description: 'אכפתיות, שיתוף פעולה ואמפתיה',
    high: 'אכפתי ומשתף פעולה',
    low: 'עצמאי ותחרותי'
  },
  neuroticism: { 
    name: 'רגישות רגשית', 
    description: 'תגובתיות רגשית ורגישות',
    high: 'רגיש ורגשי',
    low: 'יציב ורגוע'
  },
};
