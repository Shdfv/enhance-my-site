import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BigFiveResult, Gender, MatchSuggestion, PartnerPreferences, bigFiveLabels, BigFiveDimension, familyTypeLabels, UserProfile } from '@/types/personality';
import { calculateBigFiveCompatibility } from '@/data/personalityData';
import { Logo } from '@/components/Logo';
import { ProfileCard } from '@/components/ProfileCard';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, Users, Sparkles, Scale, Filter, X, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

export default function ResultsPage() {
  const navigate = useNavigate();
  const [bigFiveResult, setBigFiveResult] = useState<BigFiveResult | null>(null);
  const [userGender, setUserGender] = useState<Gender | null>(null);
  const [partnerPreferences, setPartnerPreferences] = useState<PartnerPreferences | null>(null);
  const [matchPreference, setMatchPreference] = useState<'similar' | 'complementary' | 'balanced'>('balanced');
  const [suggestions, setSuggestions] = useState<MatchSuggestion[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [registrants, setRegistrants] = useState<UserProfile[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  
  // Live filter state
  const [showFilters, setShowFilters] = useState(false);
  const [liveFilters, setLiveFilters] = useState({
    ageMin: 18,
    ageMax: 99,
    heightMin: 140,
    heightMax: 220,
    familyType: 'any' as 'ashkenazi' | 'sfaradi' | 'mixed' | 'any',
    city: '',
  });

  // Load registrants from database
  const loadRegistrants = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('registrants')
        .select('*');

      if (error) {
        console.error('Error loading registrants:', error);
        return;
      }

      // Convert database records to UserProfile format
      const profiles: UserProfile[] = (data || []).map((r: any) => ({
        id: r.id,
        name: r.full_name,
        age: r.age,
        gender: r.gender as Gender,
        location: r.city,
        height: r.height,
        studyPlace: r.study_place,
        profession: r.profession || '',
        opennessLevel: r.openness_level,
        familyType: r.family_type,
        bio: r.about_me || '',
        matchPreference: 'balanced' as const,
        bigFiveResult: {
          dimensions: {
            openness: r.big_five_openness || 50,
            conscientiousness: r.big_five_conscientiousness || 50,
            extraversion: r.big_five_extraversion || 50,
            agreeableness: r.big_five_agreeableness || 50,
            neuroticism: r.big_five_neuroticism || 50,
          },
        },
      }));

      setRegistrants(profiles);
    } catch (err) {
      console.error('Error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const storedResult = sessionStorage.getItem('bigFiveResult');
    const storedGender = sessionStorage.getItem('userGender') as Gender | null;
    const storedPreferences = sessionStorage.getItem('partnerPreferences');
    
    if (storedResult && storedGender) {
      setBigFiveResult(JSON.parse(storedResult));
      setUserGender(storedGender);
      if (storedPreferences) {
        const prefs = JSON.parse(storedPreferences) as PartnerPreferences;
        setPartnerPreferences(prefs);
        // Initialize live filters from stored preferences
        setLiveFilters({
          ageMin: prefs.ageMin,
          ageMax: prefs.ageMax,
          heightMin: prefs.heightMin,
          heightMax: prefs.heightMax,
          familyType: prefs.familyType,
          city: prefs.city,
        });
      }
      // Load registrants from database
      loadRegistrants();
    } else {
      navigate('/test');
    }
  }, [navigate]);

  const getFilteredSuggestions = () => {
    if (!bigFiveResult || !userGender) return [];

    // Filter profiles to only show opposite gender
    const oppositeGender = userGender === 'male' ? 'female' : 'male';
    let eligibleProfiles = registrants.filter(p => p.gender === oppositeGender);

    // Apply live filters
    eligibleProfiles = eligibleProfiles.filter(p => {
      if (p.age < liveFilters.ageMin || p.age > liveFilters.ageMax) return false;
      if (p.height < liveFilters.heightMin || p.height > liveFilters.heightMax) return false;
      if (liveFilters.familyType !== 'any' && p.familyType !== liveFilters.familyType) return false;
      if (liveFilters.city && !p.location.toLowerCase().includes(liveFilters.city.toLowerCase())) return false;
      return true;
    });

    const matches = eligibleProfiles.map((profile) => {
      const { score, matchingDimensions, complementaryDimensions } = calculateBigFiveCompatibility(
        bigFiveResult,
        profile.bigFiveResult,
        matchPreference
      );
      return {
        user: profile,
        compatibilityScore: score,
        matchingDimensions,
        complementaryDimensions,
      };
    });

    // Sort by compatibility score
    matches.sort((a, b) => b.compatibilityScore - a.compatibilityScore);
    return matches;
  };

  const handleFindMatches = () => {
    const matches = getFilteredSuggestions();
    setSuggestions(matches);
    setShowSuggestions(true);
  };

  // Update suggestions when filters change (if already showing suggestions)
  useEffect(() => {
    if (showSuggestions && bigFiveResult && userGender) {
      const matches = getFilteredSuggestions();
      setSuggestions(matches);
    }
  }, [liveFilters, matchPreference, registrants]);

  if (!bigFiveResult || !userGender) {
    return null;
  }

  const preferenceOptions = [
    {
      value: 'similar',
      label: 'אישיות דומה',
      description: 'מצא מישהו עם תכונות אישיות דומות לשלך',
      icon: Users,
    },
    {
      value: 'complementary',
      label: 'אישיות משלימה',
      description: 'מצא מישהו עם תכונות שונות שמשלימות אותך',
      icon: Sparkles,
    },
    {
      value: 'balanced',
      label: 'התאמה מאוזנת',
      description: 'שילוב של דמיון והבדלים להרמוניה',
      icon: Scale,
    },
  ];

  // Get dimension labels
  const getDimensionDescription = (dim: BigFiveDimension, score: number) => {
    const info = bigFiveLabels[dim];
    return score >= 50 ? info.high : info.low;
  };

  return (
    <div className="min-h-screen bg-background bg-pattern" dir="rtl">
      <header className="border-b border-border/50 bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4 flex items-center justify-between">
          <Logo size="sm" />
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => navigate('/test')}>
              הרשמה חדשה
            </Button>
          </div>
        </div>
      </header>

      <main className="container py-12">
        {!showSuggestions ? (
          <>
            <div className="text-center mb-12 animate-fade-in">
              <h1 className="text-4xl md:text-5xl font-serif font-bold text-foreground mb-4">
                פרופיל האישיות שלך
              </h1>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                תוצאות השאלון שלך
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
              {/* Big Five Result Card */}
              <Card variant="elevated" className="animate-fade-in" style={{ animationDelay: '0.1s' }}>
                <CardHeader className="text-center">
                  <CardTitle className="text-2xl">תכונות האישיות שלך</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {(Object.entries(bigFiveResult.dimensions) as [BigFiveDimension, number][]).map(([dim, score]) => (
                      <div key={dim} className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">{bigFiveLabels[dim].name}</span>
                          <span className="font-medium text-foreground">
                            {getDimensionDescription(dim, score)} ({score}%)
                          </span>
                        </div>
                        <div className="h-2 bg-secondary rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-gold-dark via-gold to-gold-light rounded-full transition-all duration-500"
                            style={{ width: `${score}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Match Preference */}
              <Card variant="elevated" className="animate-fade-in" style={{ animationDelay: '0.2s' }}>
                <CardHeader>
                  <CardTitle>העדפת התאמה</CardTitle>
                  <CardDescription>איזה סוג של בן/בת זוג את/ה מחפש/ת?</CardDescription>
                </CardHeader>
                <CardContent>
                  <RadioGroup
                    value={matchPreference}
                    onValueChange={(v) => setMatchPreference(v as typeof matchPreference)}
                    className="space-y-4"
                  >
                    {preferenceOptions.map((option) => (
                      <div key={option.value}>
                        <Label
                          htmlFor={`pref-${option.value}`}
                          className="flex items-start gap-4 p-4 rounded-lg border-2 border-transparent bg-secondary/50 hover:bg-secondary cursor-pointer transition-all [&:has([data-state=checked])]:border-gold [&:has([data-state=checked])]:bg-gold/5"
                        >
                          <RadioGroupItem value={option.value} id={`pref-${option.value}`} className="mt-1" />
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <option.icon className="w-4 h-4 text-gold" />
                              <span className="font-medium text-foreground">{option.label}</span>
                            </div>
                            <span className="block text-xs text-muted-foreground mt-2">
                              {option.description}
                            </span>
                          </div>
                        </Label>
                      </div>
                    ))}
                  </RadioGroup>

                  <Button
                    variant="gold"
                    size="lg"
                    className="w-full mt-6"
                    onClick={handleFindMatches}
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                        טוען...
                      </>
                    ) : (
                      <>
                        מצא את ההתאמות שלי
                        <ArrowLeft className="w-4 h-4 mr-2" />
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            </div>
          </>
        ) : (
          <>
            <div className="text-center mb-8 animate-fade-in">
              <h1 className="text-4xl md:text-5xl font-serif font-bold text-foreground mb-4">
                ההתאמות שלך
              </h1>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                בהתבסס על העדפת ה{matchPreference === 'similar' ? 'דומה' : matchPreference === 'complementary' ? 'משלימה' : 'מאוזנת'} שלך
              </p>
              <div className="flex justify-center gap-2 mt-4">
                <Button
                  variant="outline"
                  onClick={() => setShowSuggestions(false)}
                >
                  שנה העדפות התאמה
                </Button>
                <Button
                  variant={showFilters ? "default" : "outline"}
                  onClick={() => setShowFilters(!showFilters)}
                >
                  <Filter className="w-4 h-4 ml-2" />
                  סינון
                </Button>
              </div>
            </div>

            {/* Live Filters Panel */}
            {showFilters && (
              <Card variant="elevated" className="max-w-4xl mx-auto mb-8 animate-fade-in">
                <CardHeader className="pb-4">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">סינון תוצאות</CardTitle>
                    <Button variant="ghost" size="sm" onClick={() => setShowFilters(false)}>
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="space-y-2">
                      <Label>גיל מינימלי</Label>
                      <Input
                        type="number"
                        value={liveFilters.ageMin}
                        onChange={(e) => setLiveFilters({ ...liveFilters, ageMin: parseInt(e.target.value) || 18 })}
                        min={18}
                        max={99}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>גיל מקסימלי</Label>
                      <Input
                        type="number"
                        value={liveFilters.ageMax}
                        onChange={(e) => setLiveFilters({ ...liveFilters, ageMax: parseInt(e.target.value) || 99 })}
                        min={18}
                        max={99}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>גובה מינימלי (ס"מ)</Label>
                      <Input
                        type="number"
                        value={liveFilters.heightMin}
                        onChange={(e) => setLiveFilters({ ...liveFilters, heightMin: parseInt(e.target.value) || 140 })}
                        min={140}
                        max={220}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>גובה מקסימלי (ס"מ)</Label>
                      <Input
                        type="number"
                        value={liveFilters.heightMax}
                        onChange={(e) => setLiveFilters({ ...liveFilters, heightMax: parseInt(e.target.value) || 220 })}
                        min={140}
                        max={220}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>מוצא משפחתי</Label>
                      <Select
                        value={liveFilters.familyType}
                        onValueChange={(v) => setLiveFilters({ ...liveFilters, familyType: v as typeof liveFilters.familyType })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="any">הכל</SelectItem>
                          <SelectItem value="ashkenazi">אשכנזי</SelectItem>
                          <SelectItem value="sfaradi">ספרדי</SelectItem>
                          <SelectItem value="mixed">מעורב</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2 col-span-2 md:col-span-3">
                      <Label>עיר (השאר ריק להכל)</Label>
                      <Input
                        placeholder="לדוגמה: ירושלים"
                        value={liveFilters.city}
                        onChange={(e) => setLiveFilters({ ...liveFilters, city: e.target.value })}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {suggestions.length > 0 ? (
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 max-w-7xl mx-auto">
                {suggestions.map((suggestion, index) => (
                  <div
                    key={suggestion.user.id}
                    className="animate-fade-in"
                    style={{ animationDelay: `${index * 0.1}s` }}
                  >
                    <ProfileCard
                      profile={suggestion.user}
                      compatibilityScore={suggestion.compatibilityScore}
                      matchingTraits={suggestion.matchingDimensions}
                      complementaryTraits={suggestion.complementaryDimensions}
                      showDetails
                      onConnect={() => {
                        alert(`בקשת התחברות נשלחה!`);
                      }}
                    />
                  </div>
                ))}
              </div>
            ) : (
              <Card variant="elevated" className="max-w-md mx-auto text-center">
                <CardContent className="py-12">
                  <p className="text-muted-foreground">
                    {registrants.length === 0 
                      ? 'אין עדיין נרשמים במערכת. הנתונים שלך נשמרו ותקבל התאמות כשיהיו נרשמים נוספים.'
                      : 'לא נמצאו התאמות לפי ההעדפות שהגדרת. נסה לשנות את הסינון.'
                    }
                  </p>
                </CardContent>
              </Card>
            )}
          </>
        )}
      </main>
    </div>
  );
}
