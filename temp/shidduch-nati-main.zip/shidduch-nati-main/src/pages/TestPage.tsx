import { useNavigate } from 'react-router-dom';
import { PersonalityTest } from '@/components/PersonalityTest';
import { Logo } from '@/components/Logo';
import { BigFiveResult, Gender, SelfProfile, PartnerPreferences, Reference } from '@/types/personality';

export default function TestPage() {
  const navigate = useNavigate();

  const handleTestComplete = (
    result: BigFiveResult, 
    gender: Gender, 
    selfProfile: SelfProfile, 
    partnerPreferences: PartnerPreferences,
    references: Reference[]
  ) => {
    sessionStorage.setItem('bigFiveResult', JSON.stringify(result));
    sessionStorage.setItem('userGender', gender);
    sessionStorage.setItem('selfProfile', JSON.stringify(selfProfile));
    sessionStorage.setItem('partnerPreferences', JSON.stringify(partnerPreferences));
    sessionStorage.setItem('references', JSON.stringify(references));
    navigate('/results');
  };

  return (
    <div className="min-h-screen bg-background bg-pattern" dir="rtl">
      <header className="border-b border-border/50 bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4 flex items-center justify-center">
          <Logo size="sm" />
        </div>
      </header>

      <main className="container py-12">
        <div className="text-center mb-12 animate-fade-in">
          <h1 className="text-4xl md:text-5xl font-serif font-bold text-foreground mb-4">
            טופס הרשמה
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            מלא את הפרטים בכנות. כל המידע ישמר בצורה מאובטחת.
          </p>
        </div>

        <PersonalityTest onComplete={handleTestComplete} />
      </main>
    </div>
  );
}
