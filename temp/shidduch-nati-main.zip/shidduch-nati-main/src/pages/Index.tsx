import { Link } from 'react-router-dom';
import { Logo } from '@/components/Logo';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowLeft, Heart, Users, Sparkles, Shield, Star } from 'lucide-react';

const Index = () => {
  return (
    <div className="min-h-screen bg-background" dir="rtl">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4 flex items-center justify-between">
          <Logo />
          <nav className="hidden md:flex items-center gap-8">
            <a href="#how-it-works" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              איך זה עובד
            </a>
            <a href="#features" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              תכונות
            </a>
          </nav>
          <div className="flex items-center gap-4">
            <Button variant="ghost" asChild>
              <Link to="/test">התחברות</Link>
            </Button>
            <Button variant="gold" asChild>
              <Link to="/test">התחל עכשיו</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        {/* Background pattern */}
        <div className="absolute inset-0 bg-pattern opacity-50" />
        <div className="absolute top-0 left-0 w-[600px] h-[600px] bg-gradient-to-br from-gold/10 to-transparent rounded-full blur-3xl -translate-y-1/2 -translate-x-1/3" />
        <div className="absolute bottom-0 right-0 w-[400px] h-[400px] bg-gradient-to-tr from-primary/5 to-transparent rounded-full blur-3xl translate-y-1/2 translate-x-1/3" />

        <div className="container relative py-24 md:py-32 lg:py-40">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gold/10 border border-gold/20 text-gold mb-8 animate-fade-in">
              <Star className="w-4 h-4 fill-gold" />
              <span className="text-sm font-medium">אלפי משפחות כבר סומכות עלינו</span>
            </div>

            <h1 className="text-5xl md:text-6xl lg:text-7xl font-serif font-bold text-foreground leading-tight animate-fade-in" style={{ animationDelay: '0.1s' }}>
              מצא את
              <span className="text-gradient-gold block">הזיווג המושלם</span>
            </h1>

            <p className="mt-6 text-xl text-muted-foreground max-w-2xl mx-auto animate-fade-in" style={{ animationDelay: '0.2s' }}>
              פלטפורמת שידוכים מתחשבת שתוכננה עבור הציבור החרדי,
              המשתמשת בהתאמה מבוססת אישיות כדי לעזור לך למצוא את הבאשערט שלך.
            </p>

            <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-in" style={{ animationDelay: '0.3s' }}>
              <Button variant="hero" size="xl" asChild>
                <Link to="/test">
                  התחל את המסע
                  <ArrowLeft className="w-5 h-5 mr-2" />
                </Link>
              </Button>
              <Button variant="hero-outline" size="xl" asChild>
                <a href="#how-it-works">
                  למד עוד
                </a>
              </Button>
            </div>

            <p className="mt-6 text-sm text-muted-foreground animate-fade-in" style={{ animationDelay: '0.4s' }}>
              השידוך מן השמים — אנחנו רק עוזרים
            </p>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-24 bg-gradient-to-b from-background to-secondary/30">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-foreground mb-4">
              איך זה עובד
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              תהליך פשוט ומכבד שתוכנן עם ערכי התורה בראש
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {[
              {
                step: '01',
                title: 'מלא את השאלון',
                description: 'השלם את שאלון האישיות המתחשב שלנו כדי לגלות את התכונות והערכים הייחודיים שלך.',
                icon: Sparkles,
              },
              {
                step: '02',
                title: 'הגדר העדפות',
                description: 'בחר האם אתה מעדיף תכונות דומות, תכונות משלימות, או התאמה מאוזנת.',
                icon: Heart,
              },
              {
                step: '03',
                title: 'פגוש את ההתאמות',
                description: 'צפה בפרופילים תואמים והתחבר עם שידוכים פוטנציאליים דרך הפלטפורמה המאובטחת שלנו.',
                icon: Users,
              },
            ].map((item, index) => (
              <Card key={index} variant="elevated" className="text-center animate-fade-in" style={{ animationDelay: `${index * 0.1}s` }}>
                <CardContent className="pt-8 pb-6">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br from-gold/20 to-gold/5 border border-gold/20 mb-6">
                    <item.icon className="w-8 h-8 text-gold" />
                  </div>
                  <div className="text-sm font-bold text-gold mb-2">{item.step}</div>
                  <h3 className="text-xl font-serif font-semibold text-foreground mb-2">
                    {item.title}
                  </h3>
                  <p className="text-muted-foreground">
                    {item.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-24">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-foreground mb-4">
              נבנה בזהירות
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              כל תכונה תוכננה מתוך כבוד לערכי הקהילה שלנו
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            {[
              {
                title: 'פרטיות קודם',
                description: 'המידע שלך מוגן ומשותף רק בהסכמתך.',
                icon: Shield,
              },
              {
                title: 'ערכי תורה',
                description: 'בנוי סביב עקרונות הצניעות ודרך ארץ.',
                icon: Star,
              },
              {
                title: 'התאמה חכמה',
                description: 'אלגוריתמים מבוססי אישיות להתאמה משמעותית.',
                icon: Sparkles,
              },
              {
                title: 'מיקוד קהילתי',
                description: 'תוכנן במיוחד עבור הציבור החרדי.',
                icon: Users,
              },
            ].map((feature, index) => (
              <Card key={index} variant="interactive" className="animate-fade-in" style={{ animationDelay: `${index * 0.05}s` }}>
                <CardContent className="pt-6">
                  <feature.icon className="w-10 h-10 text-gold mb-4" />
                  <h3 className="text-lg font-serif font-semibold text-foreground mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-b from-secondary/30 to-background">
        <div className="container">
          <Card variant="gold" className="max-w-4xl mx-auto overflow-hidden">
            <CardContent className="p-12 text-center relative">
              <div className="absolute top-0 left-0 w-64 h-64 bg-gold/10 rounded-full blur-3xl -translate-y-1/2 -translate-x-1/2" />
              <div className="relative z-10">
                <Heart className="w-16 h-16 text-gold mx-auto mb-6 fill-gold/20" />
                <h2 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-4">
                  מוכן למצוא את הבאשערט?
                </h2>
                <p className="text-lg text-muted-foreground max-w-xl mx-auto mb-8">
                  עשה את הצעד הראשון לקראת מציאת השידוך המושלם שלך.
                  שאלון האישיות שלנו לוקח רק כמה דקות.
                </p>
                <Button variant="gold" size="xl" asChild>
                  <Link to="/test">
                    התחל את המסע
                    <ArrowLeft className="w-5 h-5 mr-2" />
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 py-12">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <Logo size="sm" />
            <p className="text-sm text-muted-foreground text-center">
              © 2024 מתאימים. כל הזכויות שמורות. נבנה באהבה עבור הקהילה.
            </p>
            <p className="text-sm text-muted-foreground">
              בסייעתא דשמיא
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
