import { Heart } from 'lucide-react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
}

const sizeClasses = {
  sm: 'w-8 h-8',
  md: 'w-12 h-12',
  lg: 'w-16 h-16',
};

const textSizeClasses = {
  sm: 'text-xl',
  md: 'text-2xl',
  lg: 'text-4xl',
};

export function Logo({ size = 'md', showText = true }: LogoProps) {
  return (
    <div className="flex items-center gap-3">
      <div className={`${sizeClasses[size]} relative flex items-center justify-center`}>
        <div className="absolute inset-0 bg-gradient-to-br from-gold to-gold-light rounded-lg rotate-45 opacity-20" />
        <div className="absolute inset-1 bg-gradient-to-br from-gold to-gold-light rounded-lg rotate-45 opacity-40" />
        <Heart className={`${size === 'sm' ? 'w-4 h-4' : size === 'md' ? 'w-6 h-6' : 'w-8 h-8'} text-gold relative z-10 fill-gold/30`} />
      </div>
      {showText && (
        <div className="flex flex-col">
          <span className={`${textSizeClasses[size]} font-serif font-bold text-primary leading-none`}>
            מתאימים
          </span>
          <span className="text-xs text-muted-foreground">
            מצא את ההתאמה שלך
          </span>
        </div>
      )}
    </div>
  );
}
