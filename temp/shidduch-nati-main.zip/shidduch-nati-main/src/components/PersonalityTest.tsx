import { useState } from 'react';
import { BigFiveResult, Gender, SelfProfile, PartnerPreferences, Reference, MaritalStatus, Sector, MaleStudyPlace, FemaleStudyPlace, maritalStatusLabels, sectorLabels, maleStudyPlaceLabels, femaleStudyPlaceLabels } from '@/types/personality';
import { bigFiveQuestions, calculateBigFiveResult } from '@/data/personalityData';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { ArrowRight, ArrowLeft, CheckCircle2, User } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface PersonalityTestProps {
  onComplete: (result: BigFiveResult, gender: Gender, selfProfile: SelfProfile, partnerPreferences: PartnerPreferences, references: Reference[]) => void;
}

export function PersonalityTest({ onComplete }: PersonalityTestProps) {
  const { toast } = useToast();
  const [step, setStep] = useState<'gender' | 'self-profile' | 'references' | 'partner-preferences' | 'questions' | 'complete'>('gender');
  const [gender, setGender] = useState<Gender | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const [selfProfile, setSelfProfile] = useState<SelfProfile>({
    fullName: '',
    idNumber: '',
    age: 22,
    height: 170,
    maritalStatus: 'single',
    sector: 'litai',
    origin: '',
    studyPlace: '',
    profession: '',
    opennessLevel: 'moderate',
    familyType: 'ashkenazi',
    city: '',
    aboutMe: '',
    lookingFor: '',
  });

  const [references, setReferences] = useState<Reference[]>([
    { name: '', phone: '' },
    { name: '', phone: '' },
    { name: '', phone: '' },
  ]);

  const [partnerPreferences, setPartnerPreferences] = useState<PartnerPreferences>({
    ageMin: 18,
    ageMax: 30,
    heightMin: 150,
    heightMax: 200,
    studyPlace: '',
    profession: '',
    opennessLevel: 'any',
    familyType: 'any',
    city: '',
  });

  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});

  const question = bigFiveQuestions[currentQuestion];
  const totalSteps = bigFiveQuestions.length + 4; // +4 for gender, self-profile, references, partner-preferences
  const currentStepNum = 
    step === 'gender' ? 1 : 
    step === 'self-profile' ? 2 : 
    step === 'references' ? 3 :
    step === 'partner-preferences' ? 4 : 
    currentQuestion + 5;
  const progress = (currentStepNum / totalSteps) * 100;

  const handleGenderSelect = (selectedGender: Gender) => {
    setGender(selectedGender);
    setStep('self-profile');
  };

  const handleSelfProfileNext = () => {
    // Validate required fields
    if (!selfProfile.fullName || !selfProfile.idNumber || !selfProfile.origin || !selfProfile.studyPlace || !selfProfile.city) {
      toast({
        title: "שדות חובה",
        description: "אנא מלא את כל שדות החובה",
        variant: "destructive",
      });
      return;
    }
    setStep('references');
  };

  const handleReferencesNext = () => {
    setStep('partner-preferences');
  };

  const handlePartnerPreferencesNext = () => {
    setStep('questions');
  };

  const handleAnswer = (value: number) => {
    setAnswers((prev) => ({
      ...prev,
      [question.id]: value,
    }));
  };

  const saveToDatabase = async (result: BigFiveResult) => {
    setIsSubmitting(true);
    try {
      const { error } = await supabase.from('registrants').insert({
        gender: gender!,
        full_name: selfProfile.fullName,
        id_number: selfProfile.idNumber,
        age: selfProfile.age,
        height: selfProfile.height,
        marital_status: selfProfile.maritalStatus,
        sector: selfProfile.sector,
        origin: selfProfile.origin,
        study_place: selfProfile.studyPlace,
        profession: selfProfile.profession || null,
        openness_level: selfProfile.opennessLevel,
        family_type: selfProfile.familyType,
        city: selfProfile.city,
        about_me: selfProfile.aboutMe || null,
        looking_for: selfProfile.lookingFor || null,
        partner_age_min: partnerPreferences.ageMin,
        partner_age_max: partnerPreferences.ageMax,
        partner_height_min: partnerPreferences.heightMin,
        partner_height_max: partnerPreferences.heightMax,
        partner_study_place: partnerPreferences.studyPlace || null,
        partner_profession: partnerPreferences.profession || null,
        partner_openness_level: partnerPreferences.opennessLevel,
        partner_family_type: partnerPreferences.familyType,
        partner_city: partnerPreferences.city || null,
        big_five_openness: result.dimensions.openness,
        big_five_conscientiousness: result.dimensions.conscientiousness,
        big_five_extraversion: result.dimensions.extraversion,
        big_five_agreeableness: result.dimensions.agreeableness,
        big_five_neuroticism: result.dimensions.neuroticism,
        reference1_name: references[0]?.name || null,
        reference1_phone: references[0]?.phone || null,
        reference2_name: references[1]?.name || null,
        reference2_phone: references[1]?.phone || null,
        reference3_name: references[2]?.name || null,
        reference3_phone: references[2]?.phone || null,
      });

      if (error) {
        console.error('Error saving registration:', error);
        toast({
          title: "שגיאה",
          description: "אירעה שגיאה בשמירת ההרשמה. אנא נסה שוב.",
          variant: "destructive",
        });
        return false;
      }

      toast({
        title: "ההרשמה נשמרה בהצלחה!",
        description: "הנתונים שלך נשמרו במערכת",
      });
      return true;
    } catch (err) {
      console.error('Error:', err);
      toast({
        title: "שגיאה",
        description: "אירעה שגיאה. אנא נסה שוב.",
        variant: "destructive",
      });
      return false;
    } finally {
      setIsSubmitting(false);
    }
  };

  const goNext = async () => {
    if (currentQuestion < bigFiveQuestions.length - 1) {
      setCurrentQuestion((prev) => prev + 1);
    } else {
      const result = calculateBigFiveResult(answers);
      const saved = await saveToDatabase(result);
      if (saved) {
        setStep('complete');
        onComplete(result, gender!, selfProfile, partnerPreferences, references);
      }
    }
  };

  const goBack = () => {
    if (step === 'questions') {
      if (currentQuestion > 0) {
        setCurrentQuestion((prev) => prev - 1);
      } else {
        setStep('partner-preferences');
      }
    } else if (step === 'partner-preferences') {
      setStep('references');
    } else if (step === 'references') {
      setStep('self-profile');
    } else if (step === 'self-profile') {
      setStep('gender');
      setGender(null);
    }
  };

  // Likert scale options
  const likertOptions = [
    { value: 1, label: 'לא מסכים בכלל' },
    { value: 2, label: 'לא מסכים' },
    { value: 3, label: 'ניטרלי' },
    { value: 4, label: 'מסכים' },
    { value: 5, label: 'מסכים מאוד' },
  ];

  if (step === 'complete') {
    return (
      <Card variant="elevated" className="w-full max-w-2xl mx-auto animate-scale-in" dir="rtl">
        <CardContent className="py-16 text-center">
          <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br from-gold/20 to-gold/5 flex items-center justify-center">
            <CheckCircle2 className="w-10 h-10 text-gold" />
          </div>
          <h2 className="text-3xl font-serif font-bold text-foreground mb-4">
            ההרשמה הושלמה!
          </h2>
          <p className="text-muted-foreground">
            הנתונים שלך נשמרו במערכת. מחפשים לך התאמות...
          </p>
          <div className="mt-8 max-w-xs mx-auto">
            <Progress value={100} variant="gold" className="h-2" />
          </div>
        </CardContent>
      </Card>
    );
  }

  // Gender Selection Screen
  if (step === 'gender') {
    return (
      <Card variant="elevated" className="w-full max-w-2xl mx-auto" dir="rtl">
        <CardHeader className="text-center">
          <div className="mb-4">
            <span className="text-sm text-muted-foreground">
              שלב 1 מתוך {totalSteps}
            </span>
            <Progress value={progress} variant="gold" className="mt-2 h-2" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={() => handleGenderSelect('male')}
              className="flex flex-col items-center gap-4 p-8 rounded-xl border-2 border-border/50 bg-secondary/50 hover:bg-secondary hover:border-gold transition-all group"
            >
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-500/20 to-blue-600/10 flex items-center justify-center group-hover:from-gold/20 group-hover:to-gold/5 transition-all">
                <User className="w-8 h-8 text-blue-500 group-hover:text-gold transition-colors" />
              </div>
              <div className="text-center">
                <span className="block text-lg font-semibold text-foreground">זכר</span>
              </div>
            </button>
            <button
              onClick={() => handleGenderSelect('female')}
              className="flex flex-col items-center gap-4 p-8 rounded-xl border-2 border-border/50 bg-secondary/50 hover:bg-secondary hover:border-gold transition-all group"
            >
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-pink-500/20 to-pink-600/10 flex items-center justify-center group-hover:from-gold/20 group-hover:to-gold/5 transition-all">
                <User className="w-8 h-8 text-pink-500 group-hover:text-gold transition-colors" />
              </div>
              <div className="text-center">
                <span className="block text-lg font-semibold text-foreground">נקבה</span>
              </div>
            </button>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Self Profile Screen
  if (step === 'self-profile') {
    const studyPlaceOptions = gender === 'male' 
      ? Object.entries(maleStudyPlaceLabels).map(([value, label]) => ({ value, label }))
      : Object.entries(femaleStudyPlaceLabels).map(([value, label]) => ({ value, label }));

    return (
      <Card variant="elevated" className="w-full max-w-2xl mx-auto" dir="rtl">
        <CardHeader className="text-center">
          <div className="mb-4">
            <span className="text-sm text-muted-foreground">
              שלב 2 מתוך {totalSteps}
            </span>
            <Progress value={progress} variant="gold" className="mt-2 h-2" />
          </div>
          <CardTitle className="text-2xl">פרטים אישיים</CardTitle>
          <CardDescription>ספר/י לנו על עצמך</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2 col-span-2">
              <Label>שם מלא *</Label>
              <Input
                placeholder="שם פרטי ושם משפחה"
                value={selfProfile.fullName}
                onChange={(e) => setSelfProfile({ ...selfProfile, fullName: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>ת.ז *</Label>
              <Input
                placeholder="מספר תעודת זהות"
                value={selfProfile.idNumber}
                onChange={(e) => setSelfProfile({ ...selfProfile, idNumber: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>מצב אישי *</Label>
              <Select
                value={selfProfile.maritalStatus}
                onValueChange={(v) => setSelfProfile({ ...selfProfile, maritalStatus: v as MaritalStatus })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(maritalStatusLabels).map(([value, label]) => (
                    <SelectItem key={value} value={value}>{label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>גיל *</Label>
              <Input
                type="number"
                value={selfProfile.age}
                onChange={(e) => setSelfProfile({ ...selfProfile, age: parseInt(e.target.value) || 18 })}
                min={18}
                max={99}
              />
            </div>
            <div className="space-y-2">
              <Label>גובה (ס"מ) *</Label>
              <Input
                type="number"
                value={selfProfile.height}
                onChange={(e) => setSelfProfile({ ...selfProfile, height: parseInt(e.target.value) || 160 })}
                min={140}
                max={220}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>מגזר *</Label>
              <Select
                value={selfProfile.sector}
                onValueChange={(v) => setSelfProfile({ ...selfProfile, sector: v as Sector })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(sectorLabels).map(([value, label]) => (
                    <SelectItem key={value} value={value}>{label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>מוצא *</Label>
              <Input
                placeholder="לדוגמה: מרוקאי, פולני..."
                value={selfProfile.origin}
                onChange={(e) => setSelfProfile({ ...selfProfile, origin: e.target.value })}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>מקום לימודים *</Label>
            <Select
              value={selfProfile.studyPlace}
              onValueChange={(v) => setSelfProfile({ ...selfProfile, studyPlace: v })}
            >
              <SelectTrigger>
                <SelectValue placeholder="בחר/י" />
              </SelectTrigger>
              <SelectContent>
                {studyPlaceOptions.map(({ value, label }) => (
                  <SelectItem key={value} value={value}>{label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>מקצוע / עיסוק</Label>
            <Input
              placeholder="לדוגמה: מורה, מתכנת, אברך..."
              value={selfProfile.profession}
              onChange={(e) => setSelfProfile({ ...selfProfile, profession: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label>רמת פתיחות *</Label>
            <Select
              value={selfProfile.opennessLevel}
              onValueChange={(v) => setSelfProfile({ ...selfProfile, opennessLevel: v as SelfProfile['opennessLevel'] })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="very_open">מאוד פתוח</SelectItem>
                <SelectItem value="open">פתוח</SelectItem>
                <SelectItem value="moderate">בינוני</SelectItem>
                <SelectItem value="conservative">שמרני</SelectItem>
                <SelectItem value="very_conservative">מאוד שמרני</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>מוצא משפחתי *</Label>
            <Select
              value={selfProfile.familyType}
              onValueChange={(v) => setSelfProfile({ ...selfProfile, familyType: v as SelfProfile['familyType'] })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ashkenazi">אשכנזי</SelectItem>
                <SelectItem value="sfaradi">ספרדי</SelectItem>
                <SelectItem value="mixed">מעורב</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>עיר מגורים *</Label>
            <Input
              placeholder="לדוגמה: ירושלים, בני ברק..."
              value={selfProfile.city}
              onChange={(e) => setSelfProfile({ ...selfProfile, city: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label>כמה מילים עליך</Label>
            <Textarea
              placeholder="ספר/י על עצמך, התחביבים שלך, מה חשוב לך..."
              value={selfProfile.aboutMe}
              onChange={(e) => setSelfProfile({ ...selfProfile, aboutMe: e.target.value })}
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label>מה את/ה מחפש/ת בבן/בת זוג?</Label>
            <Textarea
              placeholder="תאר/י מה חשוב לך במערכת יחסים..."
              value={selfProfile.lookingFor}
              onChange={(e) => setSelfProfile({ ...selfProfile, lookingFor: e.target.value })}
              rows={3}
            />
          </div>

          <div className="flex justify-between pt-4">
            <Button variant="ghost" onClick={goBack}>
              <ArrowRight className="w-4 h-4 ml-2" />
              חזרה
            </Button>
            <Button variant="gold" onClick={handleSelfProfileNext}>
              המשך
              <ArrowLeft className="w-4 h-4 mr-2" />
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  // References Screen (בירורים)
  if (step === 'references') {
    return (
      <Card variant="elevated" className="w-full max-w-2xl mx-auto" dir="rtl">
        <CardHeader className="text-center">
          <div className="mb-4">
            <span className="text-sm text-muted-foreground">
              שלב 3 מתוך {totalSteps}
            </span>
            <Progress value={progress} variant="gold" className="mt-2 h-2" />
          </div>
          <CardTitle className="text-2xl">בירורים</CardTitle>
          <CardDescription>אנשים שאפשר לפנות אליהם לבירור</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {references.map((ref, index) => (
            <div key={index} className="p-4 rounded-lg bg-secondary/30 space-y-4">
              <h4 className="font-medium text-foreground">איש קשר {index + 1}</h4>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>שם</Label>
                  <Input
                    placeholder="שם מלא"
                    value={ref.name}
                    onChange={(e) => {
                      const newRefs = [...references];
                      newRefs[index].name = e.target.value;
                      setReferences(newRefs);
                    }}
                  />
                </div>
                <div className="space-y-2">
                  <Label>טלפון</Label>
                  <Input
                    placeholder="מספר טלפון"
                    value={ref.phone}
                    onChange={(e) => {
                      const newRefs = [...references];
                      newRefs[index].phone = e.target.value;
                      setReferences(newRefs);
                    }}
                  />
                </div>
              </div>
            </div>
          ))}

          <div className="flex justify-between pt-4">
            <Button variant="ghost" onClick={goBack}>
              <ArrowRight className="w-4 h-4 ml-2" />
              חזרה
            </Button>
            <Button variant="gold" onClick={handleReferencesNext}>
              המשך
              <ArrowLeft className="w-4 h-4 mr-2" />
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Partner Preferences Screen
  if (step === 'partner-preferences') {
    return (
      <Card variant="elevated" className="w-full max-w-2xl mx-auto" dir="rtl">
        <CardHeader className="text-center">
          <div className="mb-4">
            <span className="text-sm text-muted-foreground">
              שלב 4 מתוך {totalSteps}
            </span>
            <Progress value={progress} variant="gold" className="mt-2 h-2" />
          </div>
          <CardTitle className="text-2xl">העדפות לבן/בת הזוג</CardTitle>
          <CardDescription>מה את/ה מחפש/ת?</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Age Range */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>גיל מינימלי</Label>
              <Input
                type="number"
                value={partnerPreferences.ageMin}
                onChange={(e) => setPartnerPreferences({ ...partnerPreferences, ageMin: parseInt(e.target.value) || 18 })}
                min={18}
                max={99}
              />
            </div>
            <div className="space-y-2">
              <Label>גיל מקסימלי</Label>
              <Input
                type="number"
                value={partnerPreferences.ageMax}
                onChange={(e) => setPartnerPreferences({ ...partnerPreferences, ageMax: parseInt(e.target.value) || 30 })}
                min={18}
                max={99}
              />
            </div>
          </div>

          {/* Height Range */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>גובה מינימלי (ס"מ)</Label>
              <Input
                type="number"
                value={partnerPreferences.heightMin}
                onChange={(e) => setPartnerPreferences({ ...partnerPreferences, heightMin: parseInt(e.target.value) || 150 })}
                min={140}
                max={220}
              />
            </div>
            <div className="space-y-2">
              <Label>גובה מקסימלי (ס"מ)</Label>
              <Input
                type="number"
                value={partnerPreferences.heightMax}
                onChange={(e) => setPartnerPreferences({ ...partnerPreferences, heightMax: parseInt(e.target.value) || 200 })}
                min={140}
                max={220}
              />
            </div>
          </div>

          {/* Study Place */}
          <div className="space-y-2">
            <Label>מקום לימודים (השאר ריק אם לא משנה)</Label>
            <Input
              placeholder="לדוגמה: ישיבה, סמינר..."
              value={partnerPreferences.studyPlace}
              onChange={(e) => setPartnerPreferences({ ...partnerPreferences, studyPlace: e.target.value })}
            />
          </div>

          {/* Profession */}
          <div className="space-y-2">
            <Label>מקצוע (השאר ריק אם לא משנה)</Label>
            <Input
              placeholder="לדוגמה: מורה, מתכנת, אברך..."
              value={partnerPreferences.profession}
              onChange={(e) => setPartnerPreferences({ ...partnerPreferences, profession: e.target.value })}
            />
          </div>

          {/* Openness Level */}
          <div className="space-y-2">
            <Label>רמת פתיחות</Label>
            <Select
              value={partnerPreferences.opennessLevel}
              onValueChange={(v) => setPartnerPreferences({ ...partnerPreferences, opennessLevel: v as PartnerPreferences['opennessLevel'] })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="any">לא משנה</SelectItem>
                <SelectItem value="very_open">מאוד פתוח</SelectItem>
                <SelectItem value="open">פתוח</SelectItem>
                <SelectItem value="moderate">בינוני</SelectItem>
                <SelectItem value="conservative">שמרני</SelectItem>
                <SelectItem value="very_conservative">מאוד שמרני</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Family Type */}
          <div className="space-y-2">
            <Label>מוצא משפחתי</Label>
            <Select
              value={partnerPreferences.familyType}
              onValueChange={(v) => setPartnerPreferences({ ...partnerPreferences, familyType: v as PartnerPreferences['familyType'] })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="any">לא משנה</SelectItem>
                <SelectItem value="ashkenazi">אשכנזי</SelectItem>
                <SelectItem value="sfaradi">ספרדי</SelectItem>
                <SelectItem value="mixed">מעורב</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* City */}
          <div className="space-y-2">
            <Label>עיר מגורים (השאר ריק אם לא משנה)</Label>
            <Input
              placeholder="לדוגמה: ירושלים, בני ברק..."
              value={partnerPreferences.city}
              onChange={(e) => setPartnerPreferences({ ...partnerPreferences, city: e.target.value })}
            />
          </div>

          <div className="flex justify-between pt-4">
            <Button variant="ghost" onClick={goBack}>
              <ArrowRight className="w-4 h-4 ml-2" />
              חזרה
            </Button>
            <Button variant="gold" onClick={handlePartnerPreferencesNext}>
              המשך לשאלון
              <ArrowLeft className="w-4 h-4 mr-2" />
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Questions Screen - Big Five with Likert Scale (no trait names shown)
  return (
    <Card variant="elevated" className="w-full max-w-2xl mx-auto" dir="rtl">
      <CardHeader className="text-center">
        <div className="mb-4">
          <span className="text-sm text-muted-foreground">
            שאלה {currentQuestion + 1} מתוך {bigFiveQuestions.length}
          </span>
          <Progress value={progress} variant="gold" className="mt-2 h-2" />
        </div>
        <CardTitle className="text-2xl">{question.question}</CardTitle>
      </CardHeader>
      <CardContent>
        <RadioGroup
          key={question.id}
          value={answers[question.id]?.toString() || ''}
          onValueChange={(v) => handleAnswer(parseInt(v))}
          className="space-y-3"
        >
          {likertOptions.map((option) => (
            <div key={option.value}>
              <Label
                htmlFor={`${question.id}-${option.value}`}
                className="flex items-center gap-4 p-4 rounded-lg border-2 border-transparent bg-secondary/50 hover:bg-secondary cursor-pointer transition-all [&:has([data-state=checked])]:border-gold [&:has([data-state=checked])]:bg-gold/5"
              >
                <RadioGroupItem value={option.value.toString()} id={`${question.id}-${option.value}`} />
                <div className="flex-1">
                  <span className="block text-foreground">{option.label}</span>
                </div>
              </Label>
            </div>
          ))}
        </RadioGroup>

        <div className="flex justify-between mt-8">
          <Button variant="ghost" onClick={goBack}>
            <ArrowRight className="w-4 h-4 ml-2" />
            חזרה
          </Button>
          <Button
            variant="gold"
            onClick={goNext}
            disabled={!answers[question.id] || isSubmitting}
          >
            {currentQuestion < bigFiveQuestions.length - 1 ? (
              <>
                הבא
                <ArrowLeft className="w-4 h-4 mr-2" />
              </>
            ) : (
              <>
                {isSubmitting ? 'שומר...' : 'סיום'}
                <CheckCircle2 className="w-4 h-4 mr-2" />
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
