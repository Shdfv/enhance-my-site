import { UserProfile, opennessLabels, familyTypeLabels, bigFiveLabels, BigFiveDimension } from '@/types/personality';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MapPin, Heart, Sparkles, User, Ruler, GraduationCap, Briefcase } from 'lucide-react';

interface ProfileCardProps {
  profile: UserProfile;
  compatibilityScore?: number;
  matchingTraits?: string[];
  complementaryTraits?: string[];
  showDetails?: boolean;
  onConnect?: () => void;
}

export function ProfileCard({
  profile,
  compatibilityScore,
  matchingTraits = [],
  complementaryTraits = [],
  showDetails = false,
  onConnect,
}: ProfileCardProps) {
  // Get top 2 personality traits (highest scores)
  const topTraits = Object.entries(profile.bigFiveResult.dimensions)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 2)
    .map(([dim]) => bigFiveLabels[dim as BigFiveDimension].name);

  return (
    <Card variant="interactive" className="overflow-hidden h-full flex flex-col" dir="rtl">
      <CardHeader className="relative pb-4">
        {compatibilityScore !== undefined && (
          <div className="absolute top-4 left-4 flex items-center gap-1 px-3 py-1 rounded-full bg-gradient-to-r from-gold/20 to-gold/10 border border-gold/30">
            <Heart className="w-3 h-3 text-gold fill-gold" />
            <span className="text-sm font-bold text-gold">{compatibilityScore}%</span>
          </div>
        )}
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
            <User className="w-8 h-8 text-primary" />
          </div>
          <div>
            <CardTitle className="text-xl">{profile.name}</CardTitle>
            <CardDescription className="flex items-center gap-1">
              <span>גיל {profile.age}</span>
              <span className="mx-1">•</span>
              <MapPin className="w-3 h-3" />
              <span>{profile.location}</span>
            </CardDescription>
          </div>
        </div>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col">
        <div className="mb-4 p-3 rounded-lg bg-secondary/50 border border-border/50 text-center">
          <p className="text-sm text-muted-foreground mb-1">תכונות בולטות</p>
          <div className="flex flex-wrap gap-1 justify-center">
            {topTraits.map((trait) => (
              <Badge key={trait} variant="secondary" className="text-xs">
                {trait}
              </Badge>
            ))}
          </div>
        </div>

        {showDetails && (
          <>
            {/* Additional Info */}
            <div className="grid grid-cols-2 gap-2 mb-4 text-sm">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Ruler className="w-4 h-4" />
                <span>{profile.height} ס"מ</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <GraduationCap className="w-4 h-4" />
                <span className="truncate">{profile.studyPlace}</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Briefcase className="w-4 h-4" />
                <span className="truncate">{profile.profession}</span>
              </div>
              <div className="text-muted-foreground">
                <Badge variant="outline" className="text-xs">
                  {familyTypeLabels[profile.familyType]}
                </Badge>
              </div>
            </div>

            <p className="text-sm text-muted-foreground mb-4 flex-1">{profile.bio}</p>

            {matchingTraits.length > 0 && (
              <div className="mb-3">
                <span className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
                  <Heart className="w-3 h-3 text-green-500" /> דומה
                </span>
                <div className="flex flex-wrap gap-1 mt-1">
                  {matchingTraits.map((trait) => (
                    <Badge key={trait} variant="secondary" className="text-xs bg-green-500/10 text-green-600 border-green-500/30">
                      {trait}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {complementaryTraits.length > 0 && (
              <div className="mb-4">
                <span className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-purple-500" /> משלים
                </span>
                <div className="flex flex-wrap gap-1 mt-1">
                  {complementaryTraits.map((trait) => (
                    <Badge key={trait} variant="secondary" className="text-xs bg-purple-500/10 text-purple-600 border-purple-500/30">
                      {trait}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {onConnect && (
              <Button variant="gold" className="w-full mt-auto" onClick={onConnect}>
                יצירת קשר
              </Button>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}
