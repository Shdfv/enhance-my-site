export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      registrants: {
        Row: {
          about_me: string | null
          age: number
          big_five_agreeableness: number | null
          big_five_conscientiousness: number | null
          big_five_extraversion: number | null
          big_five_neuroticism: number | null
          big_five_openness: number | null
          city: string
          created_at: string
          family_type: Database["public"]["Enums"]["family_type"]
          full_name: string
          gender: Database["public"]["Enums"]["gender"]
          height: number
          id: string
          id_number: string
          looking_for: string | null
          marital_status: Database["public"]["Enums"]["marital_status"]
          openness_level: Database["public"]["Enums"]["openness_level"]
          origin: string
          partner_age_max: number
          partner_age_min: number
          partner_city: string | null
          partner_family_type: string | null
          partner_height_max: number
          partner_height_min: number
          partner_openness_level: string | null
          partner_profession: string | null
          partner_study_place: string | null
          profession: string | null
          reference1_name: string | null
          reference1_phone: string | null
          reference2_name: string | null
          reference2_phone: string | null
          reference3_name: string | null
          reference3_phone: string | null
          sector: Database["public"]["Enums"]["sector"]
          study_place: string
          updated_at: string
        }
        Insert: {
          about_me?: string | null
          age: number
          big_five_agreeableness?: number | null
          big_five_conscientiousness?: number | null
          big_five_extraversion?: number | null
          big_five_neuroticism?: number | null
          big_five_openness?: number | null
          city: string
          created_at?: string
          family_type: Database["public"]["Enums"]["family_type"]
          full_name: string
          gender: Database["public"]["Enums"]["gender"]
          height: number
          id?: string
          id_number: string
          looking_for?: string | null
          marital_status: Database["public"]["Enums"]["marital_status"]
          openness_level: Database["public"]["Enums"]["openness_level"]
          origin: string
          partner_age_max?: number
          partner_age_min?: number
          partner_city?: string | null
          partner_family_type?: string | null
          partner_height_max?: number
          partner_height_min?: number
          partner_openness_level?: string | null
          partner_profession?: string | null
          partner_study_place?: string | null
          profession?: string | null
          reference1_name?: string | null
          reference1_phone?: string | null
          reference2_name?: string | null
          reference2_phone?: string | null
          reference3_name?: string | null
          reference3_phone?: string | null
          sector: Database["public"]["Enums"]["sector"]
          study_place: string
          updated_at?: string
        }
        Update: {
          about_me?: string | null
          age?: number
          big_five_agreeableness?: number | null
          big_five_conscientiousness?: number | null
          big_five_extraversion?: number | null
          big_five_neuroticism?: number | null
          big_five_openness?: number | null
          city?: string
          created_at?: string
          family_type?: Database["public"]["Enums"]["family_type"]
          full_name?: string
          gender?: Database["public"]["Enums"]["gender"]
          height?: number
          id?: string
          id_number?: string
          looking_for?: string | null
          marital_status?: Database["public"]["Enums"]["marital_status"]
          openness_level?: Database["public"]["Enums"]["openness_level"]
          origin?: string
          partner_age_max?: number
          partner_age_min?: number
          partner_city?: string | null
          partner_family_type?: string | null
          partner_height_max?: number
          partner_height_min?: number
          partner_openness_level?: string | null
          partner_profession?: string | null
          partner_study_place?: string | null
          profession?: string | null
          reference1_name?: string | null
          reference1_phone?: string | null
          reference2_name?: string | null
          reference2_phone?: string | null
          reference3_name?: string | null
          reference3_phone?: string | null
          sector?: Database["public"]["Enums"]["sector"]
          study_place?: string
          updated_at?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      family_type: "ashkenazi" | "sfaradi" | "mixed"
      female_study_place: "seminary" | "college" | "university" | "other"
      gender: "male" | "female"
      male_study_place: "yeshiva" | "kolel" | "work" | "combined" | "other"
      marital_status: "single" | "divorced" | "widowed"
      openness_level:
        | "very_open"
        | "open"
        | "moderate"
        | "conservative"
        | "very_conservative"
      sector: "litai" | "sfaradi" | "hasidi" | "temani" | "other"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      family_type: ["ashkenazi", "sfaradi", "mixed"],
      female_study_place: ["seminary", "college", "university", "other"],
      gender: ["male", "female"],
      male_study_place: ["yeshiva", "kolel", "work", "combined", "other"],
      marital_status: ["single", "divorced", "widowed"],
      openness_level: [
        "very_open",
        "open",
        "moderate",
        "conservative",
        "very_conservative",
      ],
      sector: ["litai", "sfaradi", "hasidi", "temani", "other"],
    },
  },
} as const
